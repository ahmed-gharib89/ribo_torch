# ribo_torch Package

A package for Training, testing, predicting torchvision models to help ease
the proccess needed for trying differnt models and chose the best model
for the dataset.

## Files
* classifier.py: contain a classfier class.
* utility.py: contains helper functions

## Installation

`pip install ribo-torch`

## License

This package is under MIT license for public use

