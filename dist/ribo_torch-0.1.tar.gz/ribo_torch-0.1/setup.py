from setuptools import setup

setup(name = 'ribo_torch',
      version = '0.1',
      description = 'a package for creating, training and predecting using torchvision models',
      packages= ['ribo_torch'],
      author = 'Ahmed Gharib',
      author_email = 'a.gharib89@yahoo.com',
      zip_safe = False)
